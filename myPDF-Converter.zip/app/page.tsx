"use client"

import type React from "react"

import { useState, useRef, useCallback, useEffect } from "react"
import {
  Moon,
  Sun,
  HardDrive,
  Cloud,
  FileText,
  File,
  Upload,
  X,
  CheckCircle,
  AlertCircle,
  Download,
  Loader2,
  History,
  Menu,
  Home,
  Info,
  Shield,
  Mail,
  Calendar,
  Clock,
  Trash2,
} from "lucide-react"
import { Button } from "@/components/ui/button"

interface FileUploadState {
  file: File | null
  isDragging: boolean
  isUploading: boolean
  uploadProgress: number
  isComplete: boolean
  error: string | null
  downloadState: DownloadState
}

interface DownloadState {
  isDownloading: boolean
  downloadProgress: number
  isComplete: boolean
}

interface DownloadHistoryItem {
  id: string
  originalFileName: string
  convertedFileName: string
  conversionType: "pdf-to-word" | "word-to-pdf"
  conversionDate: Date
  fileSize: number
  downloadCount: number
}

interface ContactFormData {
  name: string
  email: string
  subject: string
  message: string
}

type PageType = "home" | "about" | "privacy" | "contact" | "history"

export default function MyPDFHomepage() {
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [currentPage, setCurrentPage] = useState<PageType>("home")
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [downloadHistory, setDownloadHistory] = useState<DownloadHistoryItem[]>([])
  const [contactForm, setContactForm] = useState<ContactFormData>({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  const [isSubmittingContact, setIsSubmittingContact] = useState(false)
  const [contactSubmitted, setContactSubmitted] = useState(false)

  const [pdfUpload, setPdfUpload] = useState<FileUploadState>({
    file: null,
    isDragging: false,
    isUploading: false,
    uploadProgress: 0,
    isComplete: false,
    error: null,
    downloadState: {
      isDownloading: false,
      downloadProgress: 0,
      isComplete: false,
    },
  })
  const [wordUpload, setWordUpload] = useState<FileUploadState>({
    file: null,
    isDragging: false,
    isUploading: false,
    uploadProgress: 0,
    isComplete: false,
    error: null,
    downloadState: {
      isDownloading: false,
      downloadProgress: 0,
      isComplete: false,
    },
  })

  const pdfInputRef = useRef<HTMLInputElement>(null)
  const wordInputRef = useRef<HTMLInputElement>(null)

  // Load download history from localStorage on component mount
  useEffect(() => {
    const savedHistory = localStorage.getItem("mypdf-download-history")
    if (savedHistory) {
      const parsedHistory = JSON.parse(savedHistory).map((item: any) => ({
        ...item,
        conversionDate: new Date(item.conversionDate),
      }))
      setDownloadHistory(parsedHistory)
    }
  }, [])

  // Save download history to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("mypdf-download-history", JSON.stringify(downloadHistory))
  }, [downloadHistory])

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode)
  }

  const navigateToPage = (page: PageType) => {
    setCurrentPage(page)
    setIsMenuOpen(false)
  }

  const validateFile = (file: File, type: "pdf" | "word"): string | null => {
    const maxSize = 10 * 1024 * 1024 // 10MB

    if (file.size > maxSize) {
      return "File size must be less than 10MB"
    }

    if (type === "pdf") {
      if (file.type !== "application/pdf") {
        return "Please select a PDF file"
      }
    } else {
      const validTypes = [
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      ]
      if (!validTypes.includes(file.type) && !file.name.match(/\.(doc|docx)$/i)) {
        return "Please select a DOC or DOCX file"
      }
    }

    return null
  }

  const addToDownloadHistory = (
    originalFile: File,
    conversionType: "pdf-to-word" | "word-to-pdf",
  ): DownloadHistoryItem => {
    const originalName = originalFile.name.split(".").slice(0, -1).join(".")
    const extension = conversionType === "pdf-to-word" ? "docx" : "pdf"
    const convertedFileName = `${originalName}_converted.${extension}`

    const historyItem: DownloadHistoryItem = {
      id: Date.now().toString(),
      originalFileName: originalFile.name,
      convertedFileName,
      conversionType,
      conversionDate: new Date(),
      fileSize: originalFile.size,
      downloadCount: 1,
    }

    setDownloadHistory((prev) => [historyItem, ...prev])
    return historyItem
  }

  const simulateUpload = (setState: React.Dispatch<React.SetStateAction<FileUploadState>>, file: File) => {
    setState((prev) => ({ ...prev, isUploading: true, uploadProgress: 0, error: null }))

    const interval = setInterval(() => {
      setState((prev) => {
        const newProgress = prev.uploadProgress + Math.random() * 15
        if (newProgress >= 100) {
          clearInterval(interval)
          return {
            ...prev,
            uploadProgress: 100,
            isUploading: false,
            isComplete: true,
          }
        }
        return { ...prev, uploadProgress: newProgress }
      })
    }, 200)
  }

  const handleFileSelect = (
    file: File,
    type: "pdf" | "word",
    setState: React.Dispatch<React.SetStateAction<FileUploadState>>,
  ) => {
    const error = validateFile(file, type)
    if (error) {
      setState((prev) => ({ ...prev, error, file: null }))
      return
    }

    setState((prev) => ({ ...prev, file, error: null, isComplete: false }))
    simulateUpload(setState, file)
  }

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }, [])

  const handleDragEnter = useCallback(
    (e: React.DragEvent, setState: React.Dispatch<React.SetStateAction<FileUploadState>>) => {
      e.preventDefault()
      e.stopPropagation()
      setState((prev) => ({ ...prev, isDragging: true }))
    },
    [],
  )

  const handleDragLeave = useCallback(
    (e: React.DragEvent, setState: React.Dispatch<React.SetStateAction<FileUploadState>>) => {
      e.preventDefault()
      e.stopPropagation()
      setState((prev) => ({ ...prev, isDragging: false }))
    },
    [],
  )

  const handleDrop = useCallback(
    (e: React.DragEvent, type: "pdf" | "word", setState: React.Dispatch<React.SetStateAction<FileUploadState>>) => {
      e.preventDefault()
      e.stopPropagation()
      setState((prev) => ({ ...prev, isDragging: false }))

      const files = Array.from(e.dataTransfer.files)
      if (files.length > 0) {
        handleFileSelect(files[0], type, setState)
      }
    },
    [],
  )

  const resetUpload = (setState: React.Dispatch<React.SetStateAction<FileUploadState>>) => {
    setState({
      file: null,
      isDragging: false,
      isUploading: false,
      uploadProgress: 0,
      isComplete: false,
      error: null,
      downloadState: {
        isDownloading: false,
        downloadProgress: 0,
        isComplete: false,
      },
    })
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const formatDate = (date: Date): string => {
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const generateMockFile = (originalFile: File, outputFormat: "pdf" | "docx"): Blob => {
    const content =
      outputFormat === "pdf"
        ? "%PDF-1.4\n1 0 obj\n<<\n/Type /Catalog\n/Pages 2 0 R\n>>\nendobj\n2 0 obj\n<<\n/Type /Pages\n/Kids [3 0 R]\n/Count 1\n>>\nendobj\n3 0 obj\n<<\n/Type /Page\n/Parent 2 0 R\n/MediaBox [0 0 612 792]\n>>\nendobj\nxref\n0 4\n0000000000 65535 f \n0000000009 00000 n \n0000000074 00000 n \n0000000120 00000 n \ntrailer\n<<\n/Size 4\n/Root 1 0 R\n>>\nstartxref\n179\n%%EOF"
        : "PK\x03\x04\x14\x00\x06\x00\x08\x00\x00\x00!\x00Mock DOCX file content for demonstration purposes."

    const mimeType =
      outputFormat === "pdf"
        ? "application/pdf"
        : "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    return new Blob([content], { type: mimeType })
  }

  const downloadFile = (fileName: string, blob: Blob) => {
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = fileName
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const simulateDownload = (
    setState: React.Dispatch<React.SetStateAction<FileUploadState>>,
    file: File,
    outputFormat: "pdf" | "docx",
  ) => {
    setState((prev) => ({
      ...prev,
      downloadState: {
        isDownloading: true,
        downloadProgress: 0,
        isComplete: false,
      },
    }))

    const interval = setInterval(() => {
      setState((prev) => {
        const newProgress = prev.downloadState.downloadProgress + Math.random() * 20
        if (newProgress >= 100) {
          clearInterval(interval)

          // Add to download history
          const conversionType = outputFormat === "docx" ? "pdf-to-word" : "word-to-pdf"
          const historyItem = addToDownloadHistory(file, conversionType)

          // Generate and download the file
          const convertedFile = generateMockFile(file, outputFormat)
          downloadFile(historyItem.convertedFileName, convertedFile)

          return {
            ...prev,
            downloadState: {
              isDownloading: false,
              downloadProgress: 100,
              isComplete: true,
            },
          }
        }
        return {
          ...prev,
          downloadState: {
            ...prev.downloadState,
            downloadProgress: newProgress,
          },
        }
      })
    }, 150)
  }

  const handleDownload = (
    file: File,
    outputFormat: "pdf" | "docx",
    setState: React.Dispatch<React.SetStateAction<FileUploadState>>,
  ) => {
    simulateDownload(setState, file, outputFormat)
  }

  const handleHistoryDownload = (item: DownloadHistoryItem) => {
    // Update download count
    setDownloadHistory((prev) =>
      prev.map((historyItem) =>
        historyItem.id === item.id ? { ...historyItem, downloadCount: historyItem.downloadCount + 1 } : historyItem,
      ),
    )

    // Generate and download the file
    const outputFormat = item.conversionType === "pdf-to-word" ? "docx" : "pdf"
    const mockFile = new File(["mock content"], item.originalFileName, { type: "application/octet-stream" })
    const convertedFile = generateMockFile(mockFile, outputFormat)
    downloadFile(item.convertedFileName, convertedFile)
  }

  const clearDownloadHistory = () => {
    setDownloadHistory([])
  }

  const removeHistoryItem = (id: string) => {
    setDownloadHistory((prev) => prev.filter((item) => item.id !== id))
  }

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmittingContact(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsSubmittingContact(false)
    setContactSubmitted(true)
    setContactForm({ name: "", email: "", subject: "", message: "" })

    // Reset success message after 5 seconds
    setTimeout(() => setContactSubmitted(false), 5000)
  }

  const renderNavigation = () => (
    <nav
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isDarkMode ? "bg-gray-900/95 backdrop-blur-sm border-gray-700" : "bg-white/95 backdrop-blur-sm border-gray-200"
      } border-b`}
    >
      <div className="max-w-6xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold text-red-500 cursor-pointer" onClick={() => navigateToPage("home")}>
            MyPDF
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            <button
              onClick={() => navigateToPage("home")}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 ${
                currentPage === "home"
                  ? "text-red-500 bg-red-50 dark:bg-red-900/20"
                  : "opacity-70 hover:opacity-100 hover:text-red-500"
              }`}
            >
              <Home className="w-4 h-4" />
              Home
            </button>
            <button
              onClick={() => navigateToPage("about")}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 ${
                currentPage === "about"
                  ? "text-red-500 bg-red-50 dark:bg-red-900/20"
                  : "opacity-70 hover:opacity-100 hover:text-red-500"
              }`}
            >
              <Info className="w-4 h-4" />
              About
            </button>
            <button
              onClick={() => navigateToPage("privacy")}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 ${
                currentPage === "privacy"
                  ? "text-red-500 bg-red-50 dark:bg-red-900/20"
                  : "opacity-70 hover:opacity-100 hover:text-red-500"
              }`}
            >
              <Shield className="w-4 h-4" />
              Privacy
            </button>
            <button
              onClick={() => navigateToPage("contact")}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 ${
                currentPage === "contact"
                  ? "text-red-500 bg-red-50 dark:bg-red-900/20"
                  : "opacity-70 hover:opacity-100 hover:text-red-500"
              }`}
            >
              <Mail className="w-4 h-4" />
              Contact
            </button>
            <button
              onClick={() => navigateToPage("history")}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 ${
                currentPage === "history"
                  ? "text-red-500 bg-red-50 dark:bg-red-900/20"
                  : "opacity-70 hover:opacity-100 hover:text-red-500"
              }`}
            >
              <History className="w-4 h-4" />
              History ({downloadHistory.length})
            </button>
          </div>

          <div className="flex items-center gap-3">
            {/* Theme Toggle */}
            <Button
              onClick={toggleTheme}
              variant="outline"
              size="icon"
              className={`rounded-full transition-all duration-300 ${
                isDarkMode
                  ? "bg-gray-800 border-gray-700 hover:bg-gray-700"
                  : "bg-white border-gray-200 hover:bg-gray-50"
              }`}
            >
              {isDarkMode ? <Sun className="h-4 w-4 text-yellow-500" /> : <Moon className="h-4 w-4 text-gray-600" />}
            </Button>

            {/* Mobile Menu Toggle */}
            <Button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              variant="outline"
              size="icon"
              className={`md:hidden rounded-full transition-all duration-300 ${
                isDarkMode
                  ? "bg-gray-800 border-gray-700 hover:bg-gray-700"
                  : "bg-white border-gray-200 hover:bg-gray-50"
              }`}
            >
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex flex-col gap-2 mt-4">
              <button
                onClick={() => navigateToPage("home")}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 ${
                  currentPage === "home"
                    ? "text-red-500 bg-red-50 dark:bg-red-900/20"
                    : "opacity-70 hover:opacity-100 hover:text-red-500"
                }`}
              >
                <Home className="w-4 h-4" />
                Home
              </button>
              <button
                onClick={() => navigateToPage("about")}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 ${
                  currentPage === "about"
                    ? "text-red-500 bg-red-50 dark:bg-red-900/20"
                    : "opacity-70 hover:opacity-100 hover:text-red-500"
                }`}
              >
                <Info className="w-4 h-4" />
                About
              </button>
              <button
                onClick={() => navigateToPage("privacy")}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 ${
                  currentPage === "privacy"
                    ? "text-red-500 bg-red-50 dark:bg-red-900/20"
                    : "opacity-70 hover:opacity-100 hover:text-red-500"
                }`}
              >
                <Shield className="w-4 h-4" />
                Privacy Policy
              </button>
              <button
                onClick={() => navigateToPage("contact")}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 ${
                  currentPage === "contact"
                    ? "text-red-500 bg-red-50 dark:bg-red-900/20"
                    : "opacity-70 hover:opacity-100 hover:text-red-500"
                }`}
              >
                <Mail className="w-4 h-4" />
                Contact
              </button>
              <button
                onClick={() => navigateToPage("history")}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 ${
                  currentPage === "history"
                    ? "text-red-500 bg-red-50 dark:bg-red-900/20"
                    : "opacity-70 hover:opacity-100 hover:text-red-500"
                }`}
              >
                <History className="w-4 h-4" />
                Download History ({downloadHistory.length})
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  )

  const renderHomePage = () => (
    <div className="pt-20">
      {/* Hidden file inputs */}
      <input
        ref={pdfInputRef}
        type="file"
        accept=".pdf"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0]
          if (file) handleFileSelect(file, "pdf", setPdfUpload)
        }}
      />
      <input
        ref={wordInputRef}
        type="file"
        accept=".doc,.docx"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0]
          if (file) handleFileSelect(file, "word", setWordUpload)
        }}
      />

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center px-4 py-20">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Welcome to <span className="text-red-500">MyPDF</span> — Your Free Online PDF Toolkit
          </h1>
          <p className="text-lg md:text-xl mb-12 opacity-80 max-w-2xl mx-auto">
            Easily convert PDF to Word or Word to PDF in seconds. Fast, secure, and 100% free.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button
              className="bg-red-500 hover:bg-red-600 text-white px-8 py-4 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
              onClick={() => document.getElementById("pdf-to-word")?.scrollIntoView({ behavior: "smooth" })}
            >
              Convert PDF to Word
            </Button>
            <Button
              className="bg-red-500 hover:bg-red-600 text-white px-8 py-4 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
              onClick={() => document.getElementById("word-to-pdf")?.scrollIntoView({ behavior: "smooth" })}
            >
              Convert Word to PDF
            </Button>
          </div>

          <p className="text-sm opacity-70">No sign-up needed. Just upload and convert instantly.</p>
        </div>
      </section>

      {/* PDF to Word Converter Section */}
      <section id="pdf-to-word" className={`py-20 px-4 ${isDarkMode ? "bg-gray-800" : "bg-gray-50"}`}>
        <div className="max-w-4xl mx-auto">
          <div
            className={`rounded-2xl p-8 md:p-12 shadow-xl transition-all duration-300 ${
              isDarkMode ? "bg-gray-900" : "bg-white"
            }`}
          >
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">PDF to WORD Converter</h2>
              <p className="text-lg opacity-80 max-w-2xl mx-auto">
                Convert your PDF to editable Word documents with incredible accuracy.
              </p>
            </div>

            <div className="max-w-md mx-auto">
              <div
                className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 relative ${
                  pdfUpload.isDragging
                    ? "border-red-500 bg-red-50 dark:bg-red-900/20"
                    : pdfUpload.error
                      ? "border-red-400"
                      : pdfUpload.isComplete
                        ? "border-green-500"
                        : isDarkMode
                          ? "border-gray-600 bg-gray-800 hover:border-red-500"
                          : "border-gray-300 bg-gray-50 hover:border-red-500"
                }`}
                onDragOver={handleDragOver}
                onDragEnter={(e) => handleDragEnter(e, setPdfUpload)}
                onDragLeave={(e) => handleDragLeave(e, setPdfUpload)}
                onDrop={(e) => handleDrop(e, "pdf", setPdfUpload)}
              >
                {pdfUpload.isComplete ? (
                  <div className="space-y-4">
                    <CheckCircle className="w-16 h-16 mx-auto text-green-500" />
                    <div>
                      <p className="font-semibold text-green-600 dark:text-green-400">Conversion Complete!</p>
                      <p className="text-sm opacity-70">{pdfUpload.file?.name}</p>
                      <p className="text-xs opacity-60">{pdfUpload.file && formatFileSize(pdfUpload.file.size)}</p>
                    </div>

                    {pdfUpload.downloadState.isDownloading ? (
                      <div className="space-y-3">
                        <div className="flex items-center justify-center gap-2">
                          <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                          <span className="text-sm font-medium text-blue-600 dark:text-blue-400">
                            Preparing download...
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div
                            className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${pdfUpload.downloadState.downloadProgress}%` }}
                          ></div>
                        </div>
                        <p className="text-xs opacity-60">
                          {Math.round(pdfUpload.downloadState.downloadProgress)}% ready
                        </p>
                      </div>
                    ) : pdfUpload.downloadState.isComplete ? (
                      <div className="space-y-3">
                        <div className="flex items-center justify-center gap-2 text-green-600 dark:text-green-400">
                          <Download className="w-4 h-4" />
                          <span className="text-sm font-medium">Download completed!</span>
                        </div>
                        <div className="flex gap-2 justify-center">
                          <Button
                            onClick={() => pdfUpload.file && handleDownload(pdfUpload.file, "docx", setPdfUpload)}
                            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 text-sm rounded-lg flex items-center gap-2"
                          >
                            <Download className="w-4 h-4" />
                            Download Again
                          </Button>
                          <Button
                            variant="outline"
                            onClick={() => resetUpload(setPdfUpload)}
                            className="px-6 py-2 text-sm rounded-lg"
                          >
                            Convert Another
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex gap-2 justify-center">
                        <Button
                          onClick={() => pdfUpload.file && handleDownload(pdfUpload.file, "docx", setPdfUpload)}
                          className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 text-sm rounded-lg flex items-center gap-2 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                        >
                          <Download className="w-4 h-4" />
                          Download DOCX
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => resetUpload(setPdfUpload)}
                          className="px-6 py-2 text-sm rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-all duration-300"
                        >
                          Convert Another
                        </Button>
                      </div>
                    )}
                  </div>
                ) : pdfUpload.isUploading ? (
                  <div className="space-y-4">
                    <Upload className="w-16 h-16 mx-auto text-red-500 animate-pulse" />
                    <div>
                      <p className="font-semibold">Converting PDF...</p>
                      <p className="text-sm opacity-70">{pdfUpload.file?.name}</p>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-2">
                        <div
                          className="bg-red-500 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${pdfUpload.uploadProgress}%` }}
                        ></div>
                      </div>
                      <p className="text-xs opacity-60 mt-1">{Math.round(pdfUpload.uploadProgress)}% complete</p>
                    </div>
                  </div>
                ) : (
                  <div>
                    <FileText className="w-16 h-16 mx-auto mb-4 text-red-500" />
                    <Button
                      onClick={() => pdfInputRef.current?.click()}
                      className="bg-red-500 hover:bg-red-600 text-white px-8 py-3 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 mb-4"
                    >
                      Select PDF File
                    </Button>
                    <p className="text-sm opacity-70 mb-4">or drag and drop your PDF file here</p>

                    <div className="flex justify-center gap-4 mb-4">
                      <div className="flex items-center gap-2 text-sm opacity-70">
                        <HardDrive className="w-4 h-4" />
                        <span>Device</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm opacity-70">
                        <Cloud className="w-4 h-4" />
                        <span>Google Drive</span>
                      </div>
                    </div>

                    <p className="text-xs opacity-60">Output format: DOCX • Max size: 10MB</p>
                  </div>
                )}

                {pdfUpload.error && (
                  <div className="absolute top-2 right-2">
                    <div className="bg-red-100 dark:bg-red-900/50 border border-red-400 text-red-700 dark:text-red-400 px-3 py-2 rounded-lg text-sm flex items-center gap-2">
                      <AlertCircle className="w-4 h-4" />
                      {pdfUpload.error}
                      <button
                        onClick={() => setPdfUpload((prev) => ({ ...prev, error: null }))}
                        className="ml-2 hover:text-red-900 dark:hover:text-red-200"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Word to PDF Converter Section */}
      <section id="word-to-pdf" className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div
            className={`rounded-2xl p-8 md:p-12 shadow-xl transition-all duration-300 ${
              isDarkMode ? "bg-gray-900" : "bg-white"
            }`}
          >
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Convert WORD to PDF</h2>
              <p className="text-lg opacity-80 max-w-2xl mx-auto">
                Make your DOC or DOCX files easy to read by converting them to PDF.
              </p>
            </div>

            <div className="max-w-md mx-auto">
              <div
                className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 relative ${
                  wordUpload.isDragging
                    ? "border-red-500 bg-red-50 dark:bg-red-900/20"
                    : wordUpload.error
                      ? "border-red-400"
                      : wordUpload.isComplete
                        ? "border-green-500"
                        : isDarkMode
                          ? "border-gray-600 bg-gray-800 hover:border-red-500"
                          : "border-gray-300 bg-gray-50 hover:border-red-500"
                }`}
                onDragOver={handleDragOver}
                onDragEnter={(e) => handleDragEnter(e, setWordUpload)}
                onDragLeave={(e) => handleDragLeave(e, setWordUpload)}
                onDrop={(e) => handleDrop(e, "word", setWordUpload)}
              >
                {wordUpload.isComplete ? (
                  <div className="space-y-4">
                    <CheckCircle className="w-16 h-16 mx-auto text-green-500" />
                    <div>
                      <p className="font-semibold text-green-600 dark:text-green-400">Conversion Complete!</p>
                      <p className="text-sm opacity-70">{wordUpload.file?.name}</p>
                      <p className="text-xs opacity-60">{wordUpload.file && formatFileSize(wordUpload.file.size)}</p>
                    </div>

                    {wordUpload.downloadState.isDownloading ? (
                      <div className="space-y-3">
                        <div className="flex items-center justify-center gap-2">
                          <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                          <span className="text-sm font-medium text-blue-600 dark:text-blue-400">
                            Preparing download...
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div
                            className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${wordUpload.downloadState.downloadProgress}%` }}
                          ></div>
                        </div>
                        <p className="text-xs opacity-60">
                          {Math.round(wordUpload.downloadState.downloadProgress)}% ready
                        </p>
                      </div>
                    ) : wordUpload.downloadState.isComplete ? (
                      <div className="space-y-3">
                        <div className="flex items-center justify-center gap-2 text-green-600 dark:text-green-400">
                          <Download className="w-4 h-4" />
                          <span className="text-sm font-medium">Download completed!</span>
                        </div>
                        <div className="flex gap-2 justify-center">
                          <Button
                            onClick={() => wordUpload.file && handleDownload(wordUpload.file, "pdf", setWordUpload)}
                            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 text-sm rounded-lg flex items-center gap-2"
                          >
                            <Download className="w-4 h-4" />
                            Download Again
                          </Button>
                          <Button
                            variant="outline"
                            onClick={() => resetUpload(setWordUpload)}
                            className="px-6 py-2 text-sm rounded-lg"
                          >
                            Convert Another
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex gap-2 justify-center">
                        <Button
                          onClick={() => wordUpload.file && handleDownload(wordUpload.file, "pdf", setWordUpload)}
                          className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 text-sm rounded-lg flex items-center gap-2 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                        >
                          <Download className="w-4 h-4" />
                          Download PDF
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => resetUpload(setWordUpload)}
                          className="px-6 py-2 text-sm rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-all duration-300"
                        >
                          Convert Another
                        </Button>
                      </div>
                    )}
                  </div>
                ) : wordUpload.isUploading ? (
                  <div className="space-y-4">
                    <Upload className="w-16 h-16 mx-auto text-red-500 animate-pulse" />
                    <div>
                      <p className="font-semibold">Converting Word Document...</p>
                      <p className="text-sm opacity-70">{wordUpload.file?.name}</p>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-2">
                        <div
                          className="bg-red-500 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${wordUpload.uploadProgress}%` }}
                        ></div>
                      </div>
                      <p className="text-xs opacity-60 mt-1">{Math.round(wordUpload.uploadProgress)}% complete</p>
                    </div>
                  </div>
                ) : (
                  <div>
                    <File className="w-16 h-16 mx-auto mb-4 text-red-500" />
                    <Button
                      onClick={() => wordInputRef.current?.click()}
                      className="bg-red-500 hover:bg-red-600 text-white px-8 py-3 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 mb-4"
                    >
                      Select WORD File
                    </Button>
                    <p className="text-sm opacity-70 mb-4">or drag and drop your DOC/DOCX file here</p>

                    <div className="flex justify-center gap-4 mb-4">
                      <div className="flex items-center gap-2 text-sm opacity-70">
                        <HardDrive className="w-4 h-4" />
                        <span>Device</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm opacity-70">
                        <Cloud className="w-4 h-4" />
                        <span>Google Drive</span>
                      </div>
                    </div>

                    <p className="text-xs opacity-60">Output format: PDF • Max size: 10MB</p>
                  </div>
                )}

                {wordUpload.error && (
                  <div className="absolute top-2 right-2">
                    <div className="bg-red-100 dark:bg-red-900/50 border border-red-400 text-red-700 dark:text-red-400 px-3 py-2 rounded-lg text-sm flex items-center gap-2">
                      <AlertCircle className="w-4 h-4" />
                      {wordUpload.error}
                      <button
                        onClick={() => setWordUpload((prev) => ({ ...prev, error: null }))}
                        className="ml-2 hover:text-red-900 dark:hover:text-red-200"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )

  const renderAboutPage = () => (
    <div className="pt-20 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 py-20">
        <div
          className={`rounded-2xl p-8 md:p-12 shadow-xl transition-all duration-300 ${
            isDarkMode ? "bg-gray-900" : "bg-white"
          }`}
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              About <span className="text-red-500">MyPDF</span>
            </h1>
            <p className="text-xl opacity-80 max-w-2xl mx-auto">
              Your trusted partner for seamless PDF and Word document conversions
            </p>
          </div>

          <div className="space-y-8">
            <section>
              <h2 className="text-2xl font-bold mb-4 text-red-500">Our Mission</h2>
              <p className="text-lg opacity-80 leading-relaxed">
                At MyPDF, we believe that document conversion should be simple, fast, and accessible to everyone. Our
                mission is to provide a free, secure, and user-friendly platform that eliminates the barriers between
                different document formats, empowering users to work more efficiently with their files.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4 text-red-500">What We Offer</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div
                  className={`p-6 rounded-xl ${isDarkMode ? "bg-gray-800" : "bg-gray-50"} transition-all duration-300`}
                >
                  <FileText className="w-8 h-8 text-red-500 mb-3" />
                  <h3 className="text-lg font-semibold mb-2">PDF to Word</h3>
                  <p className="opacity-80">
                    Convert your PDF documents to editable Word files with incredible accuracy, preserving formatting
                    and layout.
                  </p>
                </div>
                <div
                  className={`p-6 rounded-xl ${isDarkMode ? "bg-gray-800" : "bg-gray-50"} transition-all duration-300`}
                >
                  <File className="w-8 h-8 text-red-500 mb-3" />
                  <h3 className="text-lg font-semibold mb-2">Word to PDF</h3>
                  <p className="opacity-80">
                    Transform your Word documents into professional PDF files that maintain their original appearance
                    across all devices.
                  </p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4 text-red-500">Why Choose MyPDF?</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div
                    className={`w-16 h-16 rounded-full ${
                      isDarkMode ? "bg-red-900/20" : "bg-red-50"
                    } flex items-center justify-center mx-auto mb-4`}
                  >
                    <CheckCircle className="w-8 h-8 text-red-500" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">100% Free</h3>
                  <p className="opacity-80">No hidden fees, no subscriptions. Our service is completely free to use.</p>
                </div>
                <div className="text-center">
                  <div
                    className={`w-16 h-16 rounded-full ${
                      isDarkMode ? "bg-red-900/20" : "bg-red-50"
                    } flex items-center justify-center mx-auto mb-4`}
                  >
                    <Shield className="w-8 h-8 text-red-500" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Secure & Private</h3>
                  <p className="opacity-80">
                    Your files are processed securely and deleted automatically after conversion.
                  </p>
                </div>
                <div className="text-center">
                  <div
                    className={`w-16 h-16 rounded-full ${
                      isDarkMode ? "bg-red-900/20" : "bg-red-50"
                    } flex items-center justify-center mx-auto mb-4`}
                  >
                    <Clock className="w-8 h-8 text-red-500" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Lightning Fast</h3>
                  <p className="opacity-80">Convert your documents in seconds with our optimized processing engine.</p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4 text-red-500">Our Team</h2>
              <p className="text-lg opacity-80 leading-relaxed mb-6">
                MyPDF is built by a passionate team of developers and designers who understand the importance of
                seamless document workflows. We're committed to continuously improving our platform and adding new
                features based on user feedback.
              </p>
              <div className="text-center">
                <Button
                  onClick={() => navigateToPage("contact")}
                  className="bg-red-500 hover:bg-red-600 text-white px-8 py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                >
                  Get in Touch
                </Button>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  )

  const renderPrivacyPage = () => (
    <div className="pt-20 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 py-20">
        <div
          className={`rounded-2xl p-8 md:p-12 shadow-xl transition-all duration-300 ${
            isDarkMode ? "bg-gray-900" : "bg-white"
          }`}
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Privacy Policy</h1>
            <p className="text-xl opacity-80 max-w-2xl mx-auto">
              Your privacy is our priority. Learn how we protect your data and respect your rights.
            </p>
          </div>

          <div className="space-y-8 text-left">
            <section>
              <h2 className="text-2xl font-bold mb-4 text-red-500">Data Collection</h2>
              <p className="text-lg opacity-80 leading-relaxed mb-4">
                MyPDF is designed with privacy in mind. We collect minimal data to provide our services:
              </p>
              <ul className="list-disc list-inside space-y-2 opacity-80">
                <li>Files you upload for conversion (temporarily processed and automatically deleted)</li>
                <li>Basic usage analytics to improve our service (anonymized)</li>
                <li>Contact information when you reach out to us (only if you choose to provide it)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4 text-red-500">How We Use Your Data</h2>
              <p className="text-lg opacity-80 leading-relaxed mb-4">We use your information solely to:</p>
              <ul className="list-disc list-inside space-y-2 opacity-80">
                <li>Process your file conversions</li>
                <li>Improve our service quality and performance</li>
                <li>Respond to your inquiries and provide customer support</li>
                <li>Ensure the security and integrity of our platform</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4 text-red-500">File Security</h2>
              <p className="text-lg opacity-80 leading-relaxed mb-4">
                Your files are our responsibility while they're in our system:
              </p>
              <ul className="list-disc list-inside space-y-2 opacity-80">
                <li>All file uploads are encrypted during transmission</li>
                <li>Files are processed in a secure, isolated environment</li>
                <li>Converted files are automatically deleted within 24 hours</li>
                <li>We never store, share, or access the content of your files</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4 text-red-500">Your Rights</h2>
              <p className="text-lg opacity-80 leading-relaxed mb-4">You have the right to:</p>
              <ul className="list-disc list-inside space-y-2 opacity-80">
                <li>Request information about data we may have collected</li>
                <li>Ask for deletion of any personal information</li>
                <li>Opt out of analytics tracking</li>
                <li>Contact us with any privacy concerns</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4 text-red-500">Cookies and Tracking</h2>
              <p className="text-lg opacity-80 leading-relaxed">
                We use minimal cookies and local storage to enhance your experience, such as remembering your theme
                preference and download history. These are stored locally on your device and can be cleared at any time
                through your browser settings.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4 text-red-500">Third-Party Services</h2>
              <p className="text-lg opacity-80 leading-relaxed">
                MyPDF does not share your data with third-party services for marketing or advertising purposes. We may
                use trusted service providers for essential functions like hosting and security, all of whom are bound
                by strict data protection agreements.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4 text-red-500">Contact Us</h2>
              <p className="text-lg opacity-80 leading-relaxed mb-4">
                If you have any questions about this Privacy Policy or our data practices, please don't hesitate to
                contact us:
              </p>
              <div className="text-center">
                <Button
                  onClick={() => navigateToPage("contact")}
                  className="bg-red-500 hover:bg-red-600 text-white px-8 py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                >
                  Contact Us
                </Button>
              </div>
            </section>

            <section className={`p-6 rounded-xl ${isDarkMode ? "bg-gray-800" : "bg-gray-50"}`}>
              <p className="text-sm opacity-70">
                <strong>Last updated:</strong> January 2025
                <br />
                This Privacy Policy may be updated from time to time. We will notify users of any significant changes.
              </p>
            </section>
          </div>
        </div>
      </div>
    </div>
  )

  const renderContactPage = () => (
    <div className="pt-20 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 py-20">
        <div
          className={`rounded-2xl p-8 md:p-12 shadow-xl transition-all duration-300 ${
            isDarkMode ? "bg-gray-900" : "bg-white"
          }`}
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Contact Us</h1>
            <p className="text-xl opacity-80 max-w-2xl mx-auto">
              Have a question or feedback? We'd love to hear from you!
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="text-2xl font-bold mb-6 text-red-500">Send us a Message</h2>
              {contactSubmitted ? (
                <div
                  className={`p-6 rounded-xl ${
                    isDarkMode ? "bg-green-900/20" : "bg-green-50"
                  } border border-green-500 text-center`}
                >
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-green-600 dark:text-green-400 mb-2">
                    Message Sent Successfully!
                  </h3>
                  <p className="opacity-80">Thank you for contacting us. We'll get back to you within 24 hours.</p>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-2">
                      Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      required
                      value={contactForm.name}
                      onChange={(e) => setContactForm((prev) => ({ ...prev, name: e.target.value }))}
                      className={`w-full px-4 py-3 rounded-lg border transition-all duration-300 ${
                        isDarkMode
                          ? "bg-gray-800 border-gray-600 focus:border-red-500"
                          : "bg-white border-gray-300 focus:border-red-500"
                      } focus:outline-none focus:ring-2 focus:ring-red-500/20`}
                      placeholder="Your full name"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-2">
                      Email *
                    </label>
                    <input
                      type="email"
                      id="email"
                      required
                      value={contactForm.email}
                      onChange={(e) => setContactForm((prev) => ({ ...prev, email: e.target.value }))}
                      className={`w-full px-4 py-3 rounded-lg border transition-all duration-300 ${
                        isDarkMode
                          ? "bg-gray-800 border-gray-600 focus:border-red-500"
                          : "bg-white border-gray-300 focus:border-red-500"
                      } focus:outline-none focus:ring-2 focus:ring-red-500/20`}
                      placeholder="your.email@example.com"
                    />
                  </div>

                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium mb-2">
                      Subject *
                    </label>
                    <input
                      type="text"
                      id="subject"
                      required
                      value={contactForm.subject}
                      onChange={(e) => setContactForm((prev) => ({ ...prev, subject: e.target.value }))}
                      className={`w-full px-4 py-3 rounded-lg border transition-all duration-300 ${
                        isDarkMode
                          ? "bg-gray-800 border-gray-600 focus:border-red-500"
                          : "bg-white border-gray-300 focus:border-red-500"
                      } focus:outline-none focus:ring-2 focus:ring-red-500/20`}
                      placeholder="What's this about?"
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium mb-2">
                      Message *
                    </label>
                    <textarea
                      id="message"
                      required
                      rows={6}
                      value={contactForm.message}
                      onChange={(e) => setContactForm((prev) => ({ ...prev, message: e.target.value }))}
                      className={`w-full px-4 py-3 rounded-lg border transition-all duration-300 resize-none ${
                        isDarkMode
                          ? "bg-gray-800 border-gray-600 focus:border-red-500"
                          : "bg-white border-gray-300 focus:border-red-500"
                      } focus:outline-none focus:ring-2 focus:ring-red-500/20`}
                      placeholder="Tell us more about your inquiry or feedback..."
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isSubmittingContact}
                    className="w-full bg-red-500 hover:bg-red-600 text-white px-8 py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                  >
                    {isSubmittingContact ? (
                      <div className="flex items-center justify-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Sending...
                      </div>
                    ) : (
                      "Send Message"
                    )}
                  </Button>
                </form>
              )}
            </div>

            {/* Contact Information */}
            <div>
              <h2 className="text-2xl font-bold mb-6 text-red-500">Get in Touch</h2>
              <div className="space-y-6">
                <div
                  className={`p-6 rounded-xl ${isDarkMode ? "bg-gray-800" : "bg-gray-50"} transition-all duration-300`}
                >
                  <div className="flex items-center gap-4 mb-4">
                    <div
                      className={`w-12 h-12 rounded-full ${
                        isDarkMode ? "bg-red-900/20" : "bg-red-50"
                      } flex items-center justify-center`}
                    >
                      <Mail className="w-6 h-6 text-red-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">Email Support</h3>
                      <p className="opacity-80">We typically respond within 24 hours</p>
                    </div>
                  </div>
                  <a
                    href="mailto:support@mypdf.com"
                    className="text-red-500 hover:text-red-600 transition-colors duration-300 font-medium"
                  >
                    support@mypdf.com
                  </a>
                </div>

                <div
                  className={`p-6 rounded-xl ${isDarkMode ? "bg-gray-800" : "bg-gray-50"} transition-all duration-300`}
                >
                  <div className="flex items-center gap-4 mb-4">
                    <div
                      className={`w-12 h-12 rounded-full ${
                        isDarkMode ? "bg-red-900/20" : "bg-red-50"
                      } flex items-center justify-center`}
                    >
                      <Clock className="w-6 h-6 text-red-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">Response Time</h3>
                      <p className="opacity-80">Monday - Friday, 9 AM - 6 PM EST</p>
                    </div>
                  </div>
                  <p className="opacity-80">We aim to respond to all inquiries within 24 hours during business days.</p>
                </div>

                <div
                  className={`p-6 rounded-xl ${isDarkMode ? "bg-gray-800" : "bg-gray-50"} transition-all duration-300`}
                >
                  <div className="flex items-center gap-4 mb-4">
                    <div
                      className={`w-12 h-12 rounded-full ${
                        isDarkMode ? "bg-red-900/20" : "bg-red-50"
                      } flex items-center justify-center`}
                    >
                      <Info className="w-6 h-6 text-red-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">Feedback & Suggestions</h3>
                      <p className="opacity-80">Help us improve MyPDF</p>
                    </div>
                  </div>
                  <p className="opacity-80">
                    We value your feedback and suggestions for new features. Your input helps us make MyPDF better for
                    everyone.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  const renderHistoryPage = () => (
    <div className="pt-20 min-h-screen">
      <div className="max-w-6xl mx-auto px-4 py-20">
        <div
          className={`rounded-2xl p-8 md:p-12 shadow-xl transition-all duration-300 ${
            isDarkMode ? "bg-gray-900" : "bg-white"
          }`}
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Download History</h1>
              <p className="text-xl opacity-80">
                View and re-download your converted files ({downloadHistory.length} total conversions)
              </p>
            </div>
            {downloadHistory.length > 0 && (
              <Button
                onClick={clearDownloadHistory}
                variant="outline"
                className="mt-4 md:mt-0 text-red-500 border-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 flex items-center gap-2 bg-transparent"
              >
                <Trash2 className="w-4 h-4" />
                Clear History
              </Button>
            )}
          </div>

          {downloadHistory.length === 0 ? (
            <div className="text-center py-16">
              <History className="w-24 h-24 mx-auto mb-6 opacity-30" />
              <h3 className="text-2xl font-semibold mb-4 opacity-70">No conversions yet</h3>
              <p className="text-lg opacity-60 mb-8">
                Start converting your files to see them appear in your download history.
              </p>
              <Button
                onClick={() => navigateToPage("home")}
                className="bg-red-500 hover:bg-red-600 text-white px-8 py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
              >
                Start Converting
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {downloadHistory.map((item) => (
                <div
                  key={item.id}
                  className={`p-6 rounded-xl border transition-all duration-300 hover:shadow-lg ${
                    isDarkMode
                      ? "bg-gray-800 border-gray-700 hover:border-gray-600"
                      : "bg-gray-50 border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        {item.conversionType === "pdf-to-word" ? (
                          <FileText className="w-5 h-5 text-red-500" />
                        ) : (
                          <File className="w-5 h-5 text-red-500" />
                        )}
                        <h3 className="text-lg font-semibold">{item.originalFileName}</h3>
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            item.conversionType === "pdf-to-word"
                              ? "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
                              : "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
                          }`}
                        >
                          {item.conversionType === "pdf-to-word" ? "PDF → WORD" : "WORD → PDF"}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-4 text-sm opacity-70">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {formatDate(item.conversionDate)}
                        </div>
                        <div className="flex items-center gap-1">
                          <File className="w-4 h-4" />
                          {formatFileSize(item.fileSize)}
                        </div>
                        <div className="flex items-center gap-1">
                          <Download className="w-4 h-4" />
                          Downloaded {item.downloadCount} time{item.downloadCount !== 1 ? "s" : ""}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Button
                        onClick={() => handleHistoryDownload(item)}
                        className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg flex items-center gap-2 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                      >
                        <Download className="w-4 h-4" />
                        Download
                      </Button>
                      <Button
                        onClick={() => removeHistoryItem(item.id)}
                        variant="outline"
                        size="icon"
                        className="text-red-500 border-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )

  return (
    <div
      className={`min-h-screen transition-colors duration-300 ${
        isDarkMode ? "bg-gray-900 text-white" : "bg-white text-black"
      }`}
    >
      {renderNavigation()}

      {currentPage === "home" && renderHomePage()}
      {currentPage === "about" && renderAboutPage()}
      {currentPage === "privacy" && renderPrivacyPage()}
      {currentPage === "contact" && renderContactPage()}
      {currentPage === "history" && renderHistoryPage()}

      {/* Footer */}
      <footer
        className={`py-8 px-4 border-t transition-colors duration-300 ${
          isDarkMode ? "bg-gray-900 border-gray-700" : "bg-white border-gray-200"
        }`}
      >
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm opacity-70">© 2025 MyPDF. All rights reserved.</p>
            <div className="flex gap-6">
              <button
                onClick={() => navigateToPage("about")}
                className="text-sm opacity-70 hover:opacity-100 hover:text-red-500 transition-all duration-300"
              >
                About
              </button>
              <button
                onClick={() => navigateToPage("privacy")}
                className="text-sm opacity-70 hover:opacity-100 hover:text-red-500 transition-all duration-300"
              >
                Privacy Policy
              </button>
              <button
                onClick={() => navigateToPage("contact")}
                className="text-sm opacity-70 hover:opacity-100 hover:text-red-500 transition-all duration-300"
              >
                Contact
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
